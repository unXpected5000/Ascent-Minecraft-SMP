scoreboard players set trigger ts.config 0
function timberstrike:config
execute at @s run playsound minecraft:block.copper_bulb.turn_on

scoreboard players set consume_durability ts.config 2
function timberstrike:config
execute at @s run playsound minecraft:block.copper.fall
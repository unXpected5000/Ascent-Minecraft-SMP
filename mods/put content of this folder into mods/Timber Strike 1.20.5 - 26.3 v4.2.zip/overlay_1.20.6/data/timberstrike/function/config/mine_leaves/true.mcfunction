scoreboard players set mine_leaves ts.config 1
function timberstrike:config
execute at @s run playsound minecraft:block.copper_bulb.turn_on
execute if block ~ ~ ~ red_mushroom_block run loot spawn ~ ~ ~ loot blocks/red_mushroom_block
execute if block ~ ~ ~ brown_mushroom_block run loot spawn ~ ~ ~ loot blocks/brown_mushroom_block

execute if block ~ ~ ~ acacia_leaves run loot spawn ~ ~ ~ loot blocks/acacia_leaves
execute if block ~ ~ ~ oak_leaves run loot spawn ~ ~ ~ loot blocks/oak_leaves
execute if block ~ ~ ~ azalea_leaves run loot spawn ~ ~ ~ loot blocks/azalea_leaves
execute if block ~ ~ ~ flowering_azalea_leaves run loot spawn ~ ~ ~ loot blocks/flowering_azalea_leaves

execute if block ~ ~ ~ spruce_leaves run loot spawn ~ ~ ~ loot blocks/spruce_leaves
execute if block ~ ~ ~ birch_leaves run loot spawn ~ ~ ~ loot blocks/birch_leaves
execute if block ~ ~ ~ jungle_leaves run loot spawn ~ ~ ~ loot blocks/jungle_leaves
execute if block ~ ~ ~ dark_oak_leaves run loot spawn ~ ~ ~ loot blocks/dark_oak_leaves
execute if block ~ ~ ~ mangrove_leaves run loot spawn ~ ~ ~ loot blocks/mangrove_leaves
execute if block ~ ~ ~ cherry_leaves run loot spawn ~ ~ ~ loot blocks/cherry_leaves

execute if block ~ ~ ~ nether_wart_block run loot spawn ~ ~ ~ loot blocks/nether_wart_block
execute if block ~ ~ ~ warped_wart_block run loot spawn ~ ~ ~ loot blocks/warped_wart_block
execute if block ~ ~ ~ shroomlight run loot spawn ~ ~ ~ loot blocks/shroomlight

setblock ~ ~ ~ air
scoreboard objectives add ts.oakmined minecraft.mined:minecraft.oak_log
scoreboard objectives add ts.sprucemined minecraft.mined:minecraft.spruce_log
scoreboard objectives add ts.birchmined minecraft.mined:minecraft.birch_log
scoreboard objectives add ts.junglemined minecraft.mined:minecraft.jungle_log
scoreboard objectives add ts.acaciamined minecraft.mined:minecraft.acacia_log
scoreboard objectives add ts.dark_oakmined minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add ts.mangrovemined minecraft.mined:minecraft.mangrove_log
scoreboard objectives add ts.cherrymined minecraft.mined:minecraft.cherry_log
scoreboard objectives add ts.warpedmined minecraft.mined:minecraft.warped_stem
scoreboard objectives add ts.crimsonmined minecraft.mined:minecraft.crimson_stem
scoreboard objectives add ts.mushroommined minecraft.mined:minecraft.mushroom_stem

scoreboard objectives add ts.config dummy
scoreboard objectives add ts.random dummy
scoreboard objectives add ts.blocklimit dummy
scoreboard objectives add ts.timer dummy


execute unless score firsttime ts.config matches 1 run scoreboard players set blocklimit ts.config 500
execute unless score firsttime ts.config matches 1 run scoreboard players set consume_durability ts.config 1
execute unless score firsttime ts.config matches 1 run scoreboard players set mine_leaves ts.config 1
execute unless score firsttime ts.config matches 1 run scoreboard players set enable_giant_mushrooms ts.config 1
execute unless score firsttime ts.config matches 1 run scoreboard players set showanimation ts.config 1
execute unless score firsttime ts.config matches 1 run scoreboard players set trigger ts.config 0


scoreboard players set firsttime ts.config 1
execute if block ~ ~ ~ acacia_log run loot spawn ~ ~ ~ loot blocks/acacia_log
execute if block ~ ~ ~ oak_log run loot spawn ~ ~ ~ loot blocks/oak_log
execute if block ~ ~ ~ spruce_log run loot spawn ~ ~ ~ loot blocks/spruce_log
execute if block ~ ~ ~ birch_log run loot spawn ~ ~ ~ loot blocks/birch_log
execute if block ~ ~ ~ jungle_log run loot spawn ~ ~ ~ loot blocks/jungle_log
execute if block ~ ~ ~ dark_oak_log run loot spawn ~ ~ ~ loot blocks/dark_oak_log
execute if block ~ ~ ~ mangrove_log run loot spawn ~ ~ ~ loot blocks/mangrove_log
execute if block ~ ~ ~ cherry_log run loot spawn ~ ~ ~ loot blocks/cherry_log

execute if block ~ ~ ~ crimson_stem run loot spawn ~ ~ ~ loot blocks/crimson_stem
execute if block ~ ~ ~ warped_stem run loot spawn ~ ~ ~ loot blocks/warped_stem
execute if block ~ ~ ~ mushroom_stem run loot spawn ~ ~ ~ loot blocks/mushroom_stem

execute if block ~ ~ ~ pale_oak_log run loot spawn ~ ~ ~ loot blocks/pale_oak_log
execute if block ~ ~ ~ poplar_log run loot spawn ~ ~ ~ loot blocks/poplar_log


setblock ~ ~ ~ air

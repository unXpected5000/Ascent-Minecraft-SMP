$scoreboard players reset @s ts.$(fungi)mined
scoreboard players add @s ts.blocklimit 1
execute if score @s ts.blocklimit > blocklimit ts.config run return run function timberstrike:mine/fail

$execute if block ~ ~ ~ $(fungi)_stem unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy
$execute if block ~ ~ ~ $(fungi)_stem if score showanimation ts.config matches 0 run function timberstrike:noanimation/log

$execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ $(wart)_wart_block unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ shroomlight unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy
$execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ $(wart)_wart_block if score showanimation ts.config matches 0 run function timberstrike:noanimation/leaves
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ shroomlight if score showanimation ts.config matches 0 run function timberstrike:noanimation/leaves

$execute positioned ~1 ~ ~ if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute positioned ~-1 ~ ~ if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute positioned ~ ~1 ~ if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute positioned ~ ~-1 ~ if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute positioned ~ ~ ~1 if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute positioned ~ ~ ~-1 if block ~ ~ ~ $(fungi)_stem run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}

$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~ if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~-1 if block ~ ~ ~ $(wart)_wart_block run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}

$execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~ if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~ if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~ if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~ if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~1 if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}
$execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~-1 if block ~ ~ ~ shroomlight run function timberstrike:mine/nether_fungi {fungi:"$(fungi)",wart:"$(wart)"}

$execute if score mine_leaves ts.config matches 2 if block ~ ~ ~ $(wart)_wart_block run return fail
execute if score consume_durability ts.config matches 0 run return fail

execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:diamond_axe run item modify entity @s weapon.mainhand timberstrike:diamond
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:golden_axe run item modify entity @s weapon.mainhand timberstrike:gold
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:iron_axe run item modify entity @s weapon.mainhand timberstrike:iron
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:stone_axe run item modify entity @s weapon.mainhand timberstrike:stone
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:wooden_axe run item modify entity @s weapon.mainhand timberstrike:wood
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:netherite_axe run item modify entity @s weapon.mainhand timberstrike:netherite
execute unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:copper_axe run item modify entity @s weapon.mainhand timberstrike:copper


execute if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] run function timberstrike:mine/unbreaking

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] run function timberstrike:mine/unbreaking2

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] run function timberstrike:mine/unbreaking3
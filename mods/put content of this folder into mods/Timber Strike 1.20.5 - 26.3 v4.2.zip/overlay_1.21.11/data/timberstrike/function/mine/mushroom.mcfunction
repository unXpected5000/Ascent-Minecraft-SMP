kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{timberstrike:1b}},id:"minecraft:knowledge_book"}},sort=nearest,limit=1]

scoreboard players reset @s ts.mushroommined
scoreboard players add @s ts.blocklimit 1
execute if score @s ts.blocklimit > blocklimit ts.config run return run function timberstrike:mine/fail

execute if block ~ ~ ~ mushroom_stem unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ red_mushroom_block unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ brown_mushroom_block unless score showanimation ts.config matches 0 run setblock ~ ~ ~ air destroy

execute if block ~ ~ ~ mushroom_stem if score showanimation ts.config matches 0 run function timberstrike:noanimation/log
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ red_mushroom_block if score showanimation ts.config matches 0 run function timberstrike:noanimation/leaves
execute unless score mine_leaves ts.config matches 0 if block ~ ~ ~ brown_mushroom_block if score showanimation ts.config matches 0 run function timberstrike:noanimation/leaves

execute positioned ~1 ~ ~ if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom
execute positioned ~-1 ~ ~ if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom
execute positioned ~ ~1 ~ if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom
execute positioned ~ ~-1 ~ if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom
execute positioned ~ ~ ~1 if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom
execute positioned ~ ~ ~-1 if block ~ ~ ~ mushroom_stem run function timberstrike:mine/mushroom

execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~ if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~-1 if block ~ ~ ~ red_mushroom_block run function timberstrike:mine/mushroom

execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~ ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~ ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~ ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~ if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~ ~-1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~1 ~-1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom
execute unless score mine_leaves ts.config matches 0 positioned ~-1 ~-1 ~-1 if block ~ ~ ~ brown_mushroom_block run function timberstrike:mine/mushroom

execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:diamond_axe run item modify entity @s weapon.mainhand timberstrike:diamond
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:golden_axe run item modify entity @s weapon.mainhand timberstrike:gold
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:iron_axe run item modify entity @s weapon.mainhand timberstrike:iron
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:stone_axe run item modify entity @s weapon.mainhand timberstrike:stone
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:wooden_axe run item modify entity @s weapon.mainhand timberstrike:wood
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:netherite_axe run item modify entity @s weapon.mainhand timberstrike:netherite
execute unless score consume_durability ts.config matches 0 unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] if items entity @s weapon.mainhand minecraft:copper_axe run item modify entity @s weapon.mainhand timberstrike:copper


execute unless score consume_durability ts.config matches 0 if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":1}}}}] run function timberstrike:mine/unbreaking

execute unless score consume_durability ts.config matches 0 if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":2}}}}] run function timberstrike:mine/unbreaking2

execute unless score consume_durability ts.config matches 0 if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{"minecraft:unbreaking":3}}}}] run function timberstrike:mine/unbreaking3
